/*
 * File: SlaveSWC_private.h
 *
 * Code generated for Simulink model 'SlaveSWC'.
 *
 * Model version                  : 1.14
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Fri Mar 21 18:09:15 2025
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SlaveSWC_private_h_
#define RTW_HEADER_SlaveSWC_private_h_
#include "rtwtypes.h"
#include "SlaveSWC_types.h"
#endif                                 /* RTW_HEADER_SlaveSWC_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
