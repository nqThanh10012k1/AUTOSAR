#include "MasterSWC.h"

const ConstB_MasterSWC_T MasterSWC_ConstB = {
  RTE_MODE_Ecu_Modes_RUN
};
