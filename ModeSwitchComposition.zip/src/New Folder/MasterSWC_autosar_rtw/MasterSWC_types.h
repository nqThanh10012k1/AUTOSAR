#ifndef RTW_HEADER_MasterSWC_types_h_
#define RTW_HEADER_MasterSWC_types_h_
#include "Rte_Type.h"
#endif

