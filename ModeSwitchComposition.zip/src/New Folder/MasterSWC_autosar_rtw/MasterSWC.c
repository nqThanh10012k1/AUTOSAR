#include "MasterSWC.h"

void SlaveSWC_Step(void)
{
  (void)Rte_Switch_MSP_Ecu_Modes_MG_Ecu_Modes(MasterSWC_ConstB.Constant);
}

void SlaveSWC_Init(void)
{
  (void)Rte_Switch_MSP_Ecu_Modes_MG_Ecu_Modes(MasterSWC_ConstB.Constant);
}
