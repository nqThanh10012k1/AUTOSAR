#ifndef RTW_HEADER_MasterSWC_private_h_
#define RTW_HEADER_MasterSWC_private_h_
#include "rtwtypes.h"
#include "MasterSWC_types.h"
#endif

